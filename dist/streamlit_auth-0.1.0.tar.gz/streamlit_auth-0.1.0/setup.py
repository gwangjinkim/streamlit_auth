# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['streamlit_auth']

package_data = \
{'': ['*']}

install_requires = \
['argon2>=0.1.10,<0.2.0', 'streamlit>=1.10,<2.0']

setup_kwargs = {
    'name': 'streamlit-auth',
    'version': '0.1.0',
    'description': 'Pre-built and secure Login/ Sign-Up page for streamlit apps - fork of `streamlit_login_auth_ui`.',
    'long_description': 'None',
    'author': 'Gwang Jin Kim',
    'author_email': 'gwang.jin.kim.phd@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
